//
//  GYMainChatViewController.swift
//  GYCompany
//
//  Created by wfd on 2022/5/19.
//  Copyright © 2022 归一. All rights reserved.
//

import UIKit
import GYSwiftKit
import GYHSKit
import MJRefresh

class GYMainChatVC: GYSwiftBaseViewController, UITableViewDelegate, UITableViewDataSource, GYCIMMsgManagerDelegate {
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupConstraints()
        
        queryMemberApplyResult()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
    }
    
    // 执行析构过程
    deinit {
        yxc_debugPrintf("===========<deinit: \(type(of: self))>===========")
    }
    
    // MARK: - Public
    override public func backButtonAction() {
        if let tmpMsg = msgManager {
            if tmpMsg.isLogin() {
                tmpMsg.logout()
            }
        }
        
        super.backButtonAction()
    }
    
    // MARK: - Protocol
    // MARK: - UITableViewDelegate
    func numberOfSections(in tableView: UITableView) -> Int {
        return dataSourceHeads.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let key = dataSourceHeads[section]
        let dataAry = dataSource[key]
        return dataAry?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 21
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let strTime = timeStampToRead(timeStamp: dataSourceHeads[section])
        let lable = UILabel().then {
            $0.text = strTime
            $0.textColor = UIColor.hexColor(0x828282)
            $0.font = .systemFont(ofSize: 14)
            $0.textAlignment = .center
        }
        lable.frame = CGRect(x: 20, y: 0, width: UIScreen.main.bounds.width, height: 21)
        return lable
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "GYMainChatBaseInfoCell") as? GYMainChatBaseInfoCell else {
            return UITableViewCell()
        }

        let key = dataSourceHeads[indexPath.section]
        let dataAry = dataSource[key]
        if indexPath.row < dataAry?.count ?? 0, let model: GYMainChatModel = dataAry?[indexPath.row] {
            cell.update(model: model)
        }
        
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_: UITableView, heightForRowAt _: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    // MARK: - UITableViewDataSource

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let key = dataSourceHeads[indexPath.section]
        let dataAry = dataSource[key]
        if indexPath.row < dataAry?.count ?? 0, let model: GYMainChatModel = dataAry?[indexPath.row] {
            yxc_debugPrintf("item select: \(String(describing: model))")
        }
    }
    
    // MARK: - GYCIMMsgManagerDelegate
    /// 接收到群消息
    func gycRecvGroup(withMessage model: GYMainChatModel!) {
        yxc_debugPrintf("accept message:\(model.modelToJSONString() ?? "" )")
        
        // 接受到群其他人发的消息
        if let tmpModel = model {
            let loginModel = CCompanyGlobalData.shareInstance().loginModel
            let currentCustId = loginModel.custId ?? ""
            let custId = model.userInfo?.custId ?? ""
            
            tmpModel.sendType = .acceptInfo
            if custId.elementsEqual(currentCustId) {
                model.sendType = .sendInfo
            }
            insertChatData(key: "\(tmpModel.msgTimeStamp)", model: tmpModel)
        }
        
    }
    
    /// 群被解散回调
    func gycGroupDismissed() {
        print("gycGroupDismissed")
    }
    
    /// 当前账号退出登录，一般是被挤下线了
    func gycKickedOffline() {
        print("gycKickedOffline")
    }

    /// 当前账号签名过期
    func gycOnUserSigExpired() {
        print("gycOnUserSigExpired")
    }

    // MARK: - IBActions
    @objc private func upBgAction() {
        let vc = GYMemberListVC()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func singleTapAction(recognizer: UITapGestureRecognizer) {
        view.endEditing(true)
        chatInputView.hiddenMoreInput()
    }
    
    // MARK: - Private
    // 查询开通会员空间申请结果
    private func queryMemberApplyResult() {
        let loginModel = CCompanyGlobalData.shareInstance().loginModel
        let parameter: [String : Any] = ["entCustId": loginModel.entCustId ?? ""]
        
        GYCompanySwiftAdapter.queryMemberApplyResult(parameter as [AnyHashable : Any]) { [weak self] (responseObject) in
            guard let responseDic = responseObject as? NSDictionary  else {
                GYUtils.showCenterToast("未查询到企业会员群信息，请稍后再试")
                yxc_debugPrintf("The responseDic: \(responseObject) is not dictionary.")
                return
            }
            
            guard let dataDic = responseDic["data"] as? NSDictionary else {
                yxc_debugPrintf("The dataDic: \(responseDic) is not dictionary")
                return
            }
            
            guard let model = GYMemberSpaceModel.mj_object(withKeyValues: dataDic) else {
                yxc_debugPrintf("Failed to parse data, dataDic: \(dataDic)")
                return
            }
            GYMemberGlobalData.memberSpaceModel = model
            self?.initShopInfo(model: model)
            
            let approveStatus = model.approveStatus?.toFloat()
            if(approveStatus == -1){
                GYUtils.showCenterToast("尚未开通会员管理，请先前往开通");
                return;
            }
            if(approveStatus == -2){
                GYUtils.showCenterToast("您企业已被平台暂停商家会员业务功能，无权使用此功能");
                return;
            }
            if(approveStatus == 0){
                GYUtils.showCenterToast("会员管理功能审批中");
                return;
            }
            if(approveStatus == 2){
                GYUtils.showCenterToast("会员管理功能审批驳回");
                return;
            }
            
            self?.queryShopImGroupId()
            
        } failure: {
            GYUtils.showCenterToast("查询开通会员空间申请结果失败");
        }
    }
    
    // 查询商家开通群聊状态，如果已开通返回群ID
    private func queryShopImGroupId() {
        let loginModel = CCompanyGlobalData.shareInstance().loginModel
        let spaceModel = GYMemberGlobalData.memberSpaceModel
        let parameter : [String: Any] = [
            "entCustId" : loginModel.entCustId ?? "",
            "infoId": spaceModel?.infoId ?? "",
            "shopLogo": spaceModel?.entLogo ?? "",
            "shopName": spaceModel?.shopName ?? "",
        ]
        
        GYCompanySwiftAdapter.queryShopImGroupId(parameter as [AnyHashable : Any]) {[weak self] (responseObject) in
            guard let responseDic = responseObject as? NSDictionary  else {
                yxc_debugPrintf("The responseDic: \(responseObject) is not dictionary.")
                return
            }
            
            guard let resultDic = responseDic["data"] as? NSDictionary else {
                yxc_debugPrintf("The responseDic: \(responseObject) is not NSDictionary.")
                return
            }
            
            let model = GYShopImGroupIdModel.mj_object(withKeyValues: resultDic)
            // openIm: 是否已开通群聊：0否   1是  2未开通会员空间   3已申请开通会员空间还未审核  4已申请开通会员空间，已审核驳回 5会员空间已开通，但停用
            if "0".elementsEqual(model?.openIm ?? "") {
                GYUtils.showMessge("是否开通群聊功能？") {
                    self?.queryShopImOpenFeeInfo()
                } cancleBlock: {
                    self?.navigationController?.popViewController(animated: true)
                }
                return
            }
            
            if  model?.groupIds?.count ?? 0 <= 0 {
                GYUtils.showCenterToast("尚未加群，暂无法入群，请联系店主加您入群");
                return
            }
            
            let groupId = String(model?.groupIds?[0] ?? "")
            self?.groupId = groupId
            
            // 修改群名称
            let groupNumber = groupId.replacingOccurrences(of: spaceModel?.infoId ?? "", with: "")
            self?.title = "会员福利群\(groupNumber)"
            
            self?.queryGroupMemberNum(groupId: groupId)
            self?.beginRefresh()
            self?.userGetUserSign(groupId: groupId)
            
        } failure: {
            GYUtils.showCenterToast("查询商家开通群聊状态失败")
        }
    }
    
    // 查询开通群聊费用信息
    private func queryShopImOpenFeeInfo() {
        let loginModel = CCompanyGlobalData.shareInstance().loginModel
        let parameter : [String: Any] = [
            "entCustId" : loginModel.entCustId ?? ""
        ]
        
        GYCompanySwiftAdapter.queryShopImOpenFeeInfo(parameter as [AnyHashable : Any]) {[weak self] (responseObject) in
            guard let responseDic = responseObject as? NSDictionary  else {
                yxc_debugPrintf("The responseDic: \(responseObject) is not dictionary.")
                return
            }
            
            guard let resultDic = responseDic["data"] as? NSDictionary else {
                yxc_debugPrintf("The responseDic: \(responseObject) is not NSDictionary.")
                return
            }
            
            let model = GYShopImOpenFeeInfoModel.mj_object(withKeyValues: resultDic)
            if let standardAmount = model?.standardAmount, let discountAmount = model?.discountAmount  {
                let tipsFormat = """
        说明：
        • 会员福利群是商家与消费者交流的工具，店主可分享店铺动态，店主及会员间聊天互动，店主可群发红包等福利，店铺挂卖品牌产品赚钱，会员分享品牌赚钱，会员下单购买赚福利。
        • 为便于管理，单群内人员数最多%@，每个商家拥有的会员福利群的个数不限，系统根据商家的会员数自动不断增加群的数量，用户加入商家会员首次进入群时，系统将自动分配该会员进入商家当时尚未满员的群。
        • 商家的管理员为每个会员福利群的店主，店主可自行为每个群添加最多4个操作员为群店员，即每个会员群由1店主+4店员%@会员共计%@成员组成。
        """
                let defaultSpace = model?.defaultSpace ?? ""
                let tmpSpace = "\((defaultSpace.toInt() ?? 5) - 5)"
                let tips = String(format: tipsFormat, arguments: [defaultSpace, tmpSpace, defaultSpace])
                
                let vc = OpenMemberPayVC()
                vc.title = "开通会员福利群功能"
                vc.tipsInfo = tips
                vc.standardAmount = standardAmount
                vc.discountAmount = discountAmount
                vc.fromePage = .memberSpaceSetting
                vc.dataModel = GYMemberGlobalData.memberSpaceModel
                vc.gyOpenMemberPayBackClosure = { [weak self] in
                    self?.navigationController?.popViewController(animated: true)
                }
                self?.navigationController?.pushViewController(vc, animated: true)
            }
            
        } failure: {
            GYUtils.showCenterToast("查询商家开通群聊状态失败")
        }
    }
    
    // 查询群成员数量
    private func queryGroupMemberNum(groupId: String) {
        let loginModel = CCompanyGlobalData.shareInstance().loginModel
        
        let parameter : [String: Any] = [
            "entCustId" : loginModel.entCustId ?? "",
            "groupId": groupId,
            "memberRole": "Admin"
        ]
        
        GYCompanySwiftAdapter.queryGroupMemberNum(parameter as [AnyHashable : Any]) {[weak self] (responseObject) in
            guard let responseDic = responseObject as? NSDictionary  else {
                yxc_debugPrintf("The responseDic: \(responseObject) is not dictionary.")
                return
            }
            
            guard let memberNumber = responseDic["data"] as? Int else {
                yxc_debugPrintf("The responseDic: \(responseObject) is not Int.")
                return
            }
            
            self?.upPeopleLable.text = "\(memberNumber)人"
        } failure: {
            GYUtils.showCenterToast("查询群成员数量失败")
        }
    }
    
    // 查询群历史消息
    private func queryGroupHistoryMsg() {
        if groupId?.count ?? 0 <= 0 {
            GYUtils.showCenterToast("没有获取到群组Id")
            return
        }
        
        var parameter : [String: Any] = ["groupId" : groupId ?? ""]
        
        if msgSeq?.count ?? 0 > 0 {
            parameter["msgReq"] = msgSeq
        }
        
        var lastTimeStamp: Double = 0
        GYCompanySwiftAdapter.queryGroupHistoryMsg(parameter as [AnyHashable : Any]) {[weak self] (responseObject) in
            self?.endRefresh()
            guard let responseDic = responseObject as? NSDictionary  else {
                yxc_debugPrintf("The responseDic: \(responseObject) is not dictionary.")
                return
            }
            
            guard let dataAry = responseDic["data"] as? NSArray else {
                yxc_debugPrintf("The responseDic: \(responseObject) is not NSArray.")
                return
            }
            
            // 没有数据时
            if dataAry.count <= 0 {
                GYUtils.showCenterToast("已加载完")
                return
            }
            
            // 首次查询清空数据
            if self?.msgSeq?.count ?? 0 <= 0 {
                self?.dataSourceHeads.removeAll()
                self?.dataSource.removeAll()
            }
            
            // 保存最后一条的记录号
            if dataAry.count > 0 {
                if let itemDic = dataAry.lastObject as? NSDictionary   {
                    self?.msgSeq = "\(itemDic["MsgSeq"] ?? "")"
                }
            }
            
            let loginModel = CCompanyGlobalData.shareInstance().loginModel
            for item in dataAry.reversed() {
                guard let itemDic = item as? NSDictionary else {
                    yxc_debugPrintf("The item:\(item) is not dictionary.")
                    continue
                }
                
                let fromAccount = itemDic["From_Account"] as? String ?? ""
                if "@TIM#SYSTEM".elementsEqual(fromAccount) {
                    yxc_debugPrintf("The fromAccount:\(String(describing: fromAccount)) is TIM System.")
                    continue
                }
                
                // 相差一分钟的用一个时间戳
                let msgTimeStamp = itemDic["MsgTimeStamp"] as? Double ?? 0
                if msgTimeStamp - lastTimeStamp > 60 {
                    lastTimeStamp = msgTimeStamp
                }
                
                guard let msgBodyAry = itemDic["MsgBody"] as? NSArray else {
                    yxc_debugPrintf("The itemDic:\(itemDic) is not NSArray.")
                    continue
                }
                
                // 只取第一个元素
                guard let msgBodyDic = msgBodyAry.firstObject as? NSDictionary else {
                    yxc_debugPrintf("The msgBodyAry:\(msgBodyAry) is empty.")
                    continue
                }
                
                guard let msgContentDic  = msgBodyDic["MsgContent"] as? NSDictionary  else {
                    yxc_debugPrintf("The msgBodyDic:\(msgBodyDic) is not NSDictionary.")
                    continue
                }
                
                guard let msgContentData  = msgContentDic["Data"] as? String  else {
                    yxc_debugPrintf("The msgContentDic:\(msgContentDic) is not String.")
                    continue
                }
                
                let msgContentDataDic = msgContentData.toDictionary()
                
                guard let contentDataDic  = msgContentDataDic["data"] as? NSDictionary  else {
                    yxc_debugPrintf("The msgBodyItemData:\(msgContentDataDic) is not NSDictionary.")
                    continue
                }
                
                if let model = GYMainChatModel.mj_object(withKeyValues: contentDataDic) {
                    model.msgTimeStamp = lastTimeStamp
                    self?.addDataSource(key: "\(lastTimeStamp)", model: model)
                    
                    model.sendType = .acceptInfo
                    if fromAccount.elementsEqual(loginModel.custId) {
                        model.sendType = .sendInfo
                    }
                }
            }
            
            self?.chatTableView.reloadData()
            if self?.dataSourceHeads.count ?? 0 > 0 {
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + .seconds(1)) {
                    self?.scrollToBottom()
                }
            }
            
            self?.chatTableView.mj_footer?.isHidden = ((self?.dataSource.count ?? 0) != 0) ? false : true
            
        } failure: { [weak self] in
            self?.endRefresh()
            GYUtils.showCenterToast("查询群历史消息失败")
        }
    }
    
    // 获取用户userSig接口
    private func userGetUserSign(groupId: String) {
        let loginModel = CCompanyGlobalData.shareInstance().loginModel
        let custId = loginModel.custId ?? ""
        
        let parameter : [String: Any] = [
            "hsResNo" : custId,
            "sdkAPPId": 1400620151
        ]
        
        GYCompanySwiftAdapter.userGetUserSign(parameter as [AnyHashable : Any]) {[weak self] (responseObject) in
            guard let responseDic = responseObject as? NSDictionary  else {
                yxc_debugPrintf("The responseDic: \(responseObject) is not dictionary.")
                return
            }
            
            guard let userSign = responseDic["data"] as? String else {
                yxc_debugPrintf("The responseDic: \(responseObject) is not Int.")
                return
            }
            
            let userInfo = self?.initCurrentUserInfo(groupId: groupId)
            self?.msgManager = GYCIMMsgManager(userSig: userSign, userInfo: userInfo)
            self?.msgManager?.delegate = self;
            
        } failure: {
            GYUtils.showCenterToast("获取用户签名信息失败")
        }
    }
    
    /// 开始刷新
    @objc private func beginRefresh() {
        chatTableView.mj_header?.beginRefreshing()
    }

    /// 设置刷新空间
    private func addRefreshView() {
        chatTableView.mj_header = MJRefreshNormalHeader(refreshingBlock: { [weak self] in
            self?.queryGroupHistoryMsg()
        })
    }
    
    /// 结束刷新
    private func endRefresh() {
        chatTableView.mj_header?.endRefreshing()
    }
    
    private func addDataSource(key: String, model: GYMainChatModel) {
        if dataSourceHeads.contains(key) {
            dataSource[key]?.append(model)
        } else {
            dataSource[key] = [model]
            dataSourceHeads.append(key)
        }
    }
    
    private func scrollToBottom() {
        if dataSourceHeads.count < 1 {
            yxc_debugPrintf("The dataSourceHeads less 1.")
            return
        }
        let section = dataSourceHeads.count - 1
        let dataAry = dataSource[self.dataSourceHeads[section]]
        let dataCount = dataAry?.count ?? 0
        if dataCount < 1 {
            yxc_debugPrintf("The dataAry less 1.")
            return
        }
        
        let indexPath = IndexPath(row: dataCount - 1, section: section)
        self.chatTableView.scrollToRow(at: indexPath, at: .bottom, animated: false)
    }
    
    private func timeStampToRead(timeStamp: String) -> String {
        let timeStamp = timeStamp.toDouble() ?? 0
        let date = NSDate(timeIntervalSince1970: timeStamp) as Date
        let strHour = GYUtils.date(toString: date, dateFormat: "HH:mm")
        
        if Calendar.current.isDateInToday(date) {
            return "今天\(strHour ?? "")"
        } else if Calendar.current.isDateInYesterday(date) {
            return "昨天\(strHour ?? "")"
        }
        
        return GYUtils.date(toString: date as Date, dateFormat: "yyyy-MM-dd HH:mm")
    }
    
    private func initShopInfo(model: GYMemberSpaceModel) {
        upStoreNameLable.text = model.shopName ?? ""
        upHsNumberLable.text = GYUtils.formatCardNo(model.entResNo)
        
        // 设置店铺头像
        let entLogo = model.entLogo ?? ""
        let entLogoURL = GYCompanySwiftAdapter.gy_PICTUREAPPENDING(entLogo)
        upHeadImagView.kf.setImage(with: URL(string: entLogoURL), placeholder: UIImage(named: "gy_assistant_main_default_head"))
    }
    
    private func initCurrentUserInfo(groupId: String) -> GYOCCharUserInfoModel {
        let loginModel = CCompanyGlobalData.shareInstance().loginModel
        let spaceModel = GYMemberGlobalData.memberSpaceModel
        
        let userInfo = GYOCCharUserInfoModel()
        userInfo.groupId = groupId
        userInfo.userName = loginModel.operName
        userInfo.userAvatar = spaceModel?.entLogo ?? ""
        userInfo.entCustId = loginModel.entCustId
        userInfo.custId = loginModel.custId
        userInfo.resNo = loginModel.entResNo
        userInfo.operNo = loginModel.userName
        
        userInfo.levelName = "店员"
        if "0000".elementsEqual(loginModel.userName) {
            userInfo.levelName = "店主"
        }
        
        userInfo.levelImg = "user_icon.png"
        return userInfo
    }
    
    // MARK: - UI
    private func setupUI() -> Void {
        yxc_debugPrintf("===========<loadClass: \(type(of: self))>===========")
        title = "会员福利群"
        
        view.addSubview(upBgView)
        upBgView.addSubview(upHeadImagView)
        upBgView.addSubview(upStoreNameLable)
        upBgView.addSubview(upHsNumberLable)
        upBgView.addSubview(upPeopleLable)
        upBgView.addSubview(upLeftArrowImagView)
        upBgView.addSubview(upBgButton)
        upBgButton.addTarget(self, action: #selector(upBgAction), for: .touchUpInside)
        
        view.addSubview(chatTableView)
        chatTableView.delegate = self
        chatTableView.dataSource = self
        addRefreshView()
        
        view.addSubview(chatInputView)
        chatInputView.parentVc = self
        chatInputView.gyChatInputClosure = { (inputType, inputInfo) in
            print("type: \(inputType), info:\(inputInfo)")
            
            if inputType == .switchGroup {
                
            } else if inputType == .redPackage {
                let gView = GYRedPacketView()
                let iHeight = UIScreen.main.bounds.height * 0.8
                gView.show(iHeight, headIcon: true, titleName: "发红包")
            } else if inputType == .pushActive {
                let gView = GYFreeActivitiesView()
                let iHeight = UIScreen.main.bounds.height * 0.8
                gView.show(iHeight, headIcon: true, titleName: "推活动")
            } else if inputType == .commendGoods {
                let listView = Bundle.main.loadNibNamed(String(describing: ChatGoodsListView.self), owner: self, options: nil)?.first as! ChatGoodsListView
                let popView = GYSPopView.show(view: listView, viewHeight: 450, showBar: true)
                popView.clickSpaceClose = true
            } else if inputType == .sendText || inputType == .sendEmoji {
                
                self.msgManager?.sendGroupTextMsg(inputInfo, completion: { (errCode, errMsg) in
                    // 发送成功后插入数据
                    if 0 == errCode {
                        yxc_debugPrintf("Sucess to send: \(inputInfo)")
                    }
                })
                
            } else if inputType == .sendVoice {
                
            }
        }
        
        let singleFinger = UITapGestureRecognizer(target: self, action: #selector(singleTapAction))
        singleFinger.numberOfTapsRequired = 1
        singleFinger.numberOfTouchesRequired = 1
        chatTableView.addGestureRecognizer(singleFinger)
    }
    
    private func insertChatData(key: String, model: GYMainChatModel) {
        // 添加数据前检测是否包含，如果包含则插入，不包含从新加载表格；表格不支持新section的插入
        let section = dataSourceHeads.firstIndex(of: key) ?? 0
        addDataSource(key: key, model: model)
        
        if section > 0 {
            let dataAry = dataSource[key]
            let indexPath = IndexPath(row: (dataAry?.count ?? 1) - 1, section: section)
            chatTableView.beginUpdates()
            chatTableView.insertRows(at: [indexPath], with:.automatic)
            chatTableView.endUpdates()
            chatTableView.scrollToRow(at: indexPath, at: .bottom, animated: false)
        } else {
            chatTableView.reloadData()
            scrollToBottom()
        }
    }
    
    // MARK: - Constraints
    private func setupConstraints() {
        upBgView.snp.makeConstraints { make in
            make.top.equalTo(0)
            make.height.equalTo(50)
            make.left.equalToSuperview()
            make.right.equalToSuperview()
        }

        upHeadImagView.snp.makeConstraints { make in
            make.width.height.equalTo(40)
            make.left.equalToSuperview().offset(10)
            make.centerY.equalToSuperview()
        }
        
        upLeftArrowImagView.snp.makeConstraints { make in
            make.width.height.equalTo(15)
            make.right.equalToSuperview().offset(-15)
            make.centerY.equalToSuperview()
        }
        
        upPeopleLable.snp.makeConstraints { make in
            make.height.equalTo(21)
            make.width.equalTo(50)
            make.right.equalTo(upLeftArrowImagView.snp.left).offset(-5)
            make.centerY.equalToSuperview()
        }
        
        upStoreNameLable.snp.makeConstraints { make in
            make.top.equalTo(5)
            make.height.equalTo(25)
            make.left.equalTo(upHeadImagView.snp.right).offset(5)
            make.right.equalTo(upPeopleLable.snp.left).offset(-5)
        }
        
        upHsNumberLable.snp.makeConstraints { make in
            make.top.equalTo(upStoreNameLable.snp.bottom)
            make.height.equalTo(15)
            make.left.equalTo(upHeadImagView.snp.right).offset(5)
            make.right.equalTo(upPeopleLable.snp.left).offset(-5)
        }
        
        upBgButton.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        chatTableView.snp.makeConstraints { make in
            make.top.equalTo(upBgView.snp.bottom)
            make.bottom.equalTo(chatInputView.snp.top)
            make.width.equalToSuperview()
        }
        
        chatInputView.snp.makeConstraints { make in
            make.bottom.equalTo(view.snp.bottom).offset(-gBottomSafeHeight)
            make.width.equalToSuperview()
        }
    }
    
    // MARK: - Property
    var groupId: String?
    var msgSeq: String? = ""
    var msgManager: GYCIMMsgManager?
    
    let upBgView = UIView().then {
        $0.backgroundColor = UIColor.hexColor(0xfdfcf4)
    }
    
    let upHeadImagView = UIImageView().then {
        $0.image = UIImage(named: "gy_assistant_main_default_head")
        $0.layer.cornerRadius = 20
        $0.layer.masksToBounds = true
    }
    
    let upStoreNameLable = UILabel().then {
        $0.text = ""
        $0.textColor = .black
        $0.font = .systemFont(ofSize: 16)
        $0.textAlignment = .left
    }
    
    let upHsNumberLable = UILabel().then {
        $0.text = ""
        $0.textColor = UIColor.hexColor(0xadaeaf)
        $0.font = .systemFont(ofSize: 12)
        $0.textAlignment = .left
    }
    
    let upPeopleLable = UILabel().then {
        $0.text = ""
        $0.textColor = .red
        $0.font = .systemFont(ofSize: 14)
        $0.textAlignment = .right
    }
    
    let upLeftArrowImagView = UIImageView().then {
        $0.image = UIImage(named: "gyhd_cell_arrow_right_icon")
    }
    
    let upBgButton = UIButton(type: .custom).then {
        $0.backgroundColor = .clear
    }
    
    let chatTableView = UITableView(frame: .zero, style: .grouped).then {
        $0.backgroundColor = UIColor.hexColor(0xeeeeee)
        $0.tableFooterView = UIView()
        $0.tableHeaderView = UIView()
        $0.showsVerticalScrollIndicator = false
        $0.separatorStyle = .none
        $0.register(GYMainChatBaseInfoCell.self, forCellReuseIdentifier: "GYMainChatBaseInfoCell")
    }
    
    var dataSourceHeads : [String] = []
    // key:时间戳，value：时间戳下的数据
    var dataSource : Dictionary<String, Array<GYMainChatModel>> = [String: Array<GYMainChatModel>]()
    
    let chatInputView = GYChatInputView()
    
}
