//
//  GYOCCharUserInfo.h
//  GYCompany
//
//  Created by applem1 on 2022/6/1.
//  Copyright © 2022 归一. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GYOCCharUserInfoModel : NSObject

@property(nonatomic,copy) NSString *groupId;
@property(nonatomic,copy) NSString *userName;
@property(nonatomic,copy) NSString *userAvatar;
@property(nonatomic,copy) NSString *entCustId;
@property(nonatomic,copy) NSString *custId;
@property(nonatomic,copy) NSString *resNo;
@property(nonatomic,copy) NSString *operNo;
@property(nonatomic,copy) NSString *levelName;
@property(nonatomic,copy) NSString *levelImg;

@end

NS_ASSUME_NONNULL_END
