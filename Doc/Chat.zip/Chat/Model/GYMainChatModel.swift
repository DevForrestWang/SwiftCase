//
//  GYMainChatModel.swift
//  GYCompany
//
//  Created by wfd on 2022/5/26.
//  Copyright © 2022 归一. All rights reserved.
//

import UIKit
import MJExtension

enum GYMainChatSendType {
    case sendInfo
    case acceptInfo
}

enum  GYMainChatMessageType {
    case text
    case voice
    case picture
    case video
    case emoji
    case activity
    case redpackage
    case goods
}

@objcMembers
class GYCCharUserInfo: NSObject {
    var groupId: String?
    var userName: String?
    var userAvatar: String?
    var entCustId: String?
    var custId: String?
    var resNo: String?
    var operNo: String?
    var levelName: String?
    var levelImg: String?
}

@objcMembers
class GYMainChatModel: NSObject {
    var sendType:GYMainChatSendType?
    var messageTpye: GYMainChatMessageType?
    
    var cmdType: String? = "" {
        didSet {
            let tmpType = cmdType ?? ""
            if "1".elementsEqual(tmpType) { // 普通文本、图标
                messageTpye = .text
            } else if "3".elementsEqual(tmpType) { //语音
                messageTpye = .voice
            } else if "4".elementsEqual(tmpType) { //图片
                messageTpye = .picture
            } else if "14".elementsEqual(tmpType) { //短视频
                messageTpye = .video
            } else if "5".elementsEqual(tmpType) { //红包
                messageTpye = .redpackage
            } else if "7".elementsEqual(tmpType) { //活动
                messageTpye = .activity
            } else if "6".elementsEqual(tmpType) { //商品
                messageTpye = .goods
            }
        }
    }
    
    var msg: Any? // 文本时：字符串，图片、音频为字典
    var userId: String?
    var sendTime: String?
    var userInfo: GYCCharUserInfo?
    // OC中并没有optional，可选类型OC赋值会报错，且要有初始值
    var msgTimeStamp: TimeInterval = 0.0

    override static func mj_objectClassInArray() -> [AnyHashable : Any]! {
        return ["userInfo": NSStringFromClass(GYCCharUserInfo.self)]
    }
}
