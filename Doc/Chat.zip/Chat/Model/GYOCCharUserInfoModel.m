//
//  GYOCCharUserInfo.m
//  GYCompany
//
//  Created by applem1 on 2022/6/1.
//  Copyright © 2022 归一. All rights reserved.
//

#import "GYOCCharUserInfoModel.h"

@implementation GYOCCharUserInfoModel

@end
